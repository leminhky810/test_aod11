package com.blossom.myapplication

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if(!isWriteExternalPermissionGranted()){
            if (Build.VERSION.SDK_INT >= 30) {
                openSettingsAllFilesAccess(this@MainActivity)

            }
        }

    }

    fun openSettingsAllFilesAccess(activity: AppCompatActivity) {

        val uri = Uri.parse("package:${BuildConfig.APPLICATION_ID}")

        startActivityForResult(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,uri),1)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.e("dad","rewre")
    }

    fun AppCompatActivity.isWriteExternalPermissionGranted(): Boolean {

        return if (Build.VERSION.SDK_INT >= 30) {
            checkSelfPermission(
                    if (Build.VERSION.SDK_INT >= 30)
                        Manifest.permission.MANAGE_EXTERNAL_STORAGE
                    else Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }
}